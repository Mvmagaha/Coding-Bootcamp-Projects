from flask import Flask, render_template, redirect, session, request
from datetime import datetime
import random
app=Flask(__name__)

app.secret_key='Keeping this business secret'

@app.route('/')
def index():
    if "gold_bars" not in session:
        session["gold_bars"] = 0
    if "activities" not in session:
        session["activities"] = []

    activities = session["activities"]

    reversed_activities=[]
    for i in range(len(activities)-1, -1, -1):
        reversed_activities.append(activities[i])
    
    return render_template('index.html', activities=reversed_activities)


@app.route('/process_gold', methods=['POST'])
def process_points():
    location = request.form["location"]
    activities = session['activities']

    if location == "farm":
        earnedValue = random.randint(10, 20)
    elif location == "cave":
        earnedValue = random.randint(5, 10)
    elif location == "house":
        earnedValue = random.randint(2, 5)
    elif location == "casino":
        earnedValue = random.randint(-50, 50)

    activities.append({
        "activityName": location,
        "earnedValue": earnedValue,
        "date": datetime.now()
    })

    session["gold_bars"] += earnedValue
    session["activities"] = activities
    return redirect('/')

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')

if __name__=="__main__":
    app.run(debug=True)